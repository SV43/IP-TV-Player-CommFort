# PasLibVlc
PasLibVlc is interface to VideoLAN libvlc.dll and VCL player component for Delphi / FreePascal based on VideoLAN

author: **Robert Jędrzejczyk** \
www: **http://prog.olsztyn.pl/paslibvlc**

Copy of version **3.0.8**: https://prog.olsztyn.pl/paslibvlc/download_src/3.0.8/PasLibVlc_3.0.8.zip
