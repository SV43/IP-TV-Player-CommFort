Высота и ширина картинки для кнопки не должна превышать 64x64px

иконки взяты
https://www.iconfinder.com/search/icons?family=evericons